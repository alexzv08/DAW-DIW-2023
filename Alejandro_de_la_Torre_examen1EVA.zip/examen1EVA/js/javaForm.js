window.onload = function(){
    input = document.querySelectorAll("input");
    input.forEach(element => {
        element.classList.add("tracking-in-expand")
        
    });
  
}